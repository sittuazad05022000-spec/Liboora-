# PRD-012a — Security & Automation — Delivery Package

| Field | Value |
|---|---|
| **PRD** | `PRD-012a` — Security & Automation (the SECURITY platform) |
| **Status** | **FROZEN** |
| **Rank** | **3** |
| **Parts** | **1–8** (eight files, v0.1 … v0.8) |
| **Acceptance criteria** | **128** (`SECP-AC-001` … `SECP-AC-128`) |
| **Implementation tasks** | **60** (`IMPL-1300` … `IMPL-1359`) |
| **Current commit** | **`f55317a`** |
| **Baseline** | `BASELINE-2026-08-21-A` |
| **Conferring authority** | `ACCEPTED` `ADR-0064` + `DOCUMENTATION_BASELINE.md` §3.3 (L198) and §4 (L252) |
| **Package date** | 2026-08-22 |
| **Files in package** | **15** (14 deliverables + this manifest) |

---

## 1. Package contents — complete list

### 1.1 The specification — Parts 1–8

| # | File | Version | Content |
|---|---|---|---|
| 1 | `PRD-012a_SECURITY_AUTOMATION.md` | v0.1 | **Part 1** — scope, principles, ownership. §0.5 records that this platform owns **no bounded context** |
| 2 | `PRD-012a_PART2_PLATFORM_ADMIN_SECURITY.md` | v0.2 | **Part 2** — platform admin security, privileged access. Opens `SECP-FR-001`…`018`, `SECP-BR-001`…`008`, `SECP-HRO-001`…`012` |
| 3 | `PRD-012a_PART3_ZERO_TRUST_IAM_TENANT_SECURITY.md` | v0.3 | **Part 3** — zero trust, IAM, tenant isolation |
| 4 | `PRD-012a_PART4_APPLICATION_API_SESSION_DATA_SECURITY.md` | v0.4 | **Part 4** — application, API, session and data security |
| 5 | `PRD-012a_PART5_THREAT_DETECTION_MONITORING_ALERTS.md` | v0.5 | **Part 5** — threat detection, monitoring, alerting |
| 6 | `PRD-012a_PART6_SECURITY_AUTOMATION_INCIDENT_RESPONSE.md` | v0.6 | **Part 6** — security automation and incident response |
| 7 | `PRD-012a_PART7_AUDIT_VULNERABILITY_TESTING_RESILIENCE.md` | v0.7 | **Part 7** — audit, vulnerability testing, resilience |
| 8 | `PRD-012a_PART8_TRACEABILITY_AND_ACCEPTANCE.md` | v0.8 | **Part 8** — the traceability and acceptance register; the 7 `SECP-DEP-*` (§7) and the 5 `SECP-ADR-*` (§8) |

### 1.2 Continuity

| # | File | Version | Content |
|---|---|---|---|
| 9 | `PRD-012a_CONTINUITY_SUMMARY.md` | v0.8 | Cross-Part continuity summary and register state |

### 1.3 Stage gate records

| # | File | Stage | Verdict |
|---|---|---|---|
| 10 | `PRD-012a_ARCHITECTURE_ALIGNMENT.md` | **Stage 3** — Architecture Review | ⚠ **ALIGNED WITH ONE STRUCTURAL FINDING** — 5 of 6 PASS + 1 PASS-BY-CONSTRUCTION-WITH-FINDING; 3 findings accepted, **4 rejected with reasons**, **3 conflicts routed and 0 resolved** |
| 11 | `PRD-012a_STAGE4_REQUIREMENTS_REVIEW.md` | **Stage 4** — Requirements Review | ✅ **PASS 6 of 6** — 4 candidate findings rejected, **3 instrument defects disclosed**, 3 conflicts deferred each with a reason **and** a named owner |
| 12 | `PRD-012a_STAGE6_IMPLEMENTATION_TASKS.md` | **Stage 6** — Implementation Tasks | ✅ **Verdict A — PASS** — `IMPL-1300`…`1359`, reserve `1360`…`1399` |
| 13 | `PRD-012a_STAGE7_FREEZE.md` | **Stage 7** — Freeze & Governance | ✅ **PASS — FROZEN at Rank 3.** All ten mandatory gate clauses satisfied; **eleven items not closed, each with a reason AND a named owner** |

### 1.4 Final implementation task document

| # | File | Content |
|---|---|---|
| 14 | `PRD-012a_IMPLEMENTATION_TASKS.md` | The final implementation task document — **60 tasks**, `IMPL-1300` … `IMPL-1359`, plus reserve `1360`…`1399`. Source path in repository: `docs/40-implementation/security/` |

### 1.5 This manifest

| # | File | Content |
|---|---|---|
| 15 | `README.md` | This file |

---

## 2. ⚠ Stage 5 — why there is no `PRD-012a_STAGE5_*.md` file in this package

**There is no such file in the repository, and none was created for this package.**

Six other PRDs carry a standalone Stage 5 artefact — `PRD-013`, `PRD-014`, `PRD-016`, `PRD-017` and `PRD-023` as
`*_STAGE5_CONFERRAL.md`, and `PRD-007` as `PRD-007_STAGE5_TRACEABILITY.md`. **`PRD-012a` carries none.** Its Stage 5
record is **§2N of `docs/40-implementation/TRACEABILITY_MATRIX.md`**, which is the repository's central traceability
register and is **not a `PRD-012a` deliverable** — it registers every module, so shipping it here would ship fifteen
other modules' inventories inside a `PRD-012a` package.

**The Stage 5 result is therefore reported rather than enclosed:**

| Stage 5 measurement | Value |
|---|---|
| Identifiers registered | **427** |
| Registers | **15**, every one **contiguous `1..max`** |
| Collisions | **0**, measured in four directions |
| Class A obligations | **109** (84 `SECP-FR-*` + 25 `SECP-BR-*`) |
| Coverage | **109 / 109 = 100.0%** by **128** `SECP-AC-*` |
| Prefix | `SECP-`, because `SEC-` was **measured at 155 hits and rejected** — `INV-SEC-001`…`071` is owned by the frozen Rank 3 Invitation Security Specification |

⛔ **A file was not invented to fill the row.** The gap in the naming convention is stated instead, and the substance
that a Stage 5 file would have contained is reproduced above and in **Part 8 §5**, which is enclosed.

---

## 3. Register summary — measured from the enclosed Parts

| Register | Count | Range | Contiguous |
|---|---|---|---|
| `SECP-AC-*` | **128** | 001–128 | ✅ |
| `SECP-FR-*` | **84** | 001–084 | ✅ |
| `SECP-XC-*` | **37** | 001–037 | ✅ |
| `SECP-OWN-*` | **30** | 001–030 | ✅ |
| `SECP-BR-*` | **25** | 001–025 | ✅ |
| `SECP-GAP-*` | **44** | 001–044 | ✅ |
| `SECP-HRO-*` | **12** | 001–012 | ✅ **CLOSED** |
| `SECP-OBJ-*` | **12** | 001–012 | ✅ |
| `SECP-PRN-*` | **12** | 001–012 | ✅ |
| `SECP-SIG-*` | **10** | 001–010 | ✅ **CLOSED** |
| `SECP-TRC-*` | **9** | 001–009 | ✅ |
| `SECP-TST-*` | **8** | 001–008 | ✅ **CLOSED** |
| `SECP-DEP-*` | **7** | 001–007 | ✅ |
| `SECP-ADR-*` | **5** | 001–005 | ✅ |
| `SECP-SEV-*` | **4** | 001–004 | ✅ **CLOSED** |
| **TOTAL** | **427** | **15 registers** | **all contiguous** |

⚠ **Three registers are declared EMPTY with published reasons**, each a finding rather than an omission:
`SECP-INV-*` (no owned aggregate — `SECP-GAP-010`), `SECP-EVT-*` (no BC Map producer row), `SECP-CFG-*` (would
duplicate `BC-25`).

⚠ **Four registers are CLOSED** and may not be extended without an ADR.

⚠ **The enclosed Parts' `SECP-GAP-*` register tops out at 044.** `SECP-GAP-045`, `046` and `047` exist **only in the
ADRs that opened them** (`ADR-0060`, `ADR-0062`), because the freeze did not edit the subject. **The total is 47 open
gaps; 44 of them are declared in these files.** The two figures are not a discrepancy.

---

## 4. What FROZEN does **not** mean

| A reader might assume | Measured |
|---|---|
| Acceptance criteria are proven | ⛔ **0 of 128** |
| Implementation tasks are done | ⛔ **0 of 60** |
| Open questions are settled | ⛔ **0 of 47 closed — all 47 OPEN** |
| Code exists | ⛔ **0 lines.** `lib/platform/security/` does not exist |

`SID-4.56`: *"A rule that cannot be checked SHALL be treated as unmet."*

⛔ **`SECP-FR-018` retains its `PENDING-AUTHORITY` marker** in Part 2 (L332, L348, L452, L526, L544, L555) even though
`ADR-0063` has **substantively satisfied** its condition. Removing the marker is an amendment to a frozen Rank 3
document requiring its own ADR. **An implementer MUST read `ADR-0063` beside Part 2.**

---

## 5. Authority — five ADRs, three roles

| `SECP-ADR-*` | Resolved by | Authority |
|---|---|---|
| `SECP-ADR-001` | `ADR-0060` | **Architecture Owner** — the SECURITY platform gets **no `BC-nn`**; Stage 1 `NOT APPLICABLE`. **No `BC-32` created** |
| `SECP-ADR-002` | `ADR-0061` | **Architecture Owner** — Rank 3 alertability outranks the Rank 6 EA `V2` tag; **the EA was not edited** |
| `SECP-ADR-003` | `ADR-0063` | **`BC-18` Identity & Access owner** — a SECURITY obligation on `BC-18`'s existing mechanism; frozen `AUTH-8.81` neither amended nor contradicted |
| `SECP-ADR-004` | `ADR-0062` | **Architecture Owner** — all four outbound `port` declarations **REFUSED**; `tool/module_dependencies.yaml` byte-unchanged |
| `SECP-ADR-005` | `ADR-0064` | **Governance Owner** — the admission to Rank 3 |

⚠ **`ADR-0033` §7.1: *"A conferral for one act is not a standing licence."*** Three distinct roles signed these five
decisions. Had one role signed all five, the admission would have been a single actor agreeing with itself.

**The ADRs are governance records under `docs/00-governance/adr/` and are deliberately NOT enclosed** — they are not
`PRD-012a` deliverables, and copying them here would create a second, drifting copy of a ranked governance document.

---

## 6. `SECP-DEP-*` — dependency status

| ID | Status | Owner |
|---|---|---|
| `SECP-DEP-001` | ✅ Closed by `ADR-0061` | Architecture Owner |
| `SECP-DEP-002` | ✅ Closed by `ADR-0063` | `BC-18` owner |
| `SECP-DEP-003` | ✅ Closed by `ADR-0062` | Architecture Owner |
| `SECP-DEP-004` | ✅ Closed by `ADR-0060` | Architecture Owner |
| `SECP-DEP-005` | ⬜ **OPEN** — `BC-24`'s support-access category list (`AUD-GAP-004`) | **`BC-24` owner** |
| `SECP-DEP-006` | ✅ Met — `TRACEABILITY_MATRIX.md` §2N | — |
| `SECP-DEP-007` | ⚠ **PARTIAL** — registry half done; **`PRD_OWNERSHIP_MODEL.md` half OUTSTANDING** | **Governance Owner** |

⚠ **`SECP-DEP-007` is the one item worth reading twice.** Part 8 **L358** requires `PRD_REGISTRY.md` §4.1 **and**
`PRD_OWNERSHIP_MODEL.md` to be updated. Only the registry was. `ADR-0064` §4 item 5 discharges it *"for the
registry"*, while that ADR's **header row overclaims** *"Closes … `SECP-DEP-007`"* — and a search of `ADR-0064` for
any mention of the ownership model returns **zero occurrences**, so **no decision authorises the second edit**. It is
routed to the Governance Owner, not performed. See `PRD-012a_STAGE7_FREEZE.md` §6.1.

---

## 7. Where these files live in the repository

| Package file | Repository path |
|---|---|
| Parts 1–8, Continuity, Stages 3/4/6/7 | `docs/30-product/security/` |
| `PRD-012a_IMPLEMENTATION_TASKS.md` | `docs/40-implementation/security/` |

**Every enclosed file is a byte-for-byte copy of the repository file at commit `f55317a`.** Nothing was edited,
reformatted or regenerated for packaging. **Excluded by construction:** `.git`, source code, tests, build output,
logs, temporary files, generated artefacts, and every document that is not a `PRD-012a` deliverable — including
`DOCUMENTATION_BASELINE.md`, `PRD_REGISTRY.md`, `TRACEABILITY_MATRIX.md`, `PRD_LIFECYCLE.md` and the five ADRs, all
of which are **ranked governance documents whose only authoritative copy is the one in the repository.**

⚠ **`PRD-012a_STAGE7_BLOCKER.md` is also excluded.** It is a real `PRD-012a` stage artefact and it is **retained in
the repository** — the baseline admits it at §3.3 as *"SUPERSEDED IN SUBSTANCE by `ADR-0064` and retained rather than
deleted"* — but its four blockers are **all now closed**, and enclosing a superseded ⛔ BLOCKED verdict beside the
✅ PASS record it was superseded by would mislead a reader of this package. The freeze record covers all four
blockers and names the ADR that closed each.
