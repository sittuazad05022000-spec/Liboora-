# PRD-017 — File & Media — Developer Handoff Package

| Field | Value |
|---|---|
| **PRD** | `PRD-017` — File & Media |
| **Version** | **v0.2** (amended from v0.1 by `ACCEPTED` `ADR-0056`) |
| **Status** | **`FROZEN`** — Stage 7 complete, conferred by `ACCEPTED` `ADR-0054` |
| **Owning bounded context** | **`BC-29` File & Media** `[GENERIC]` — Platform Services |
| **Module path** | `platform/services` (rank 3) |
| **Integration edge** | **`E-22`** — consumers `BC-01`, `BC-10`, `BC-12`, `BC-14` (BC Map v1.8 L331) |
| **Baseline** | `BASELINE-2026-08-20-C` |
| **Package built** | 2026-08-21 |
| **Repository commit** | see `delivery/` commit in the `Liboora-` repository |

> ⛔ **READ THIS FIRST — `FROZEN` IS NOT `VERIFIED`.**
> `FROZEN` means the requirements are agreed and may not be silently changed. It does **not** mean they
> are implemented, and it does **not** mean they are proven. **0 of 96 acceptance criteria (`FIL-AC-*`)
> are proven against real storage.** Do not read this package as a description of working software.
> §5 and §7 below state exactly what exists and what does not.

---

## 1. What PRD-017 is for

`PRD-017` specifies the **File & Media capability** of Liboora — the single module through which every
other part of the product stores, retrieves and serves binary content: profile photographs, uploaded
identity and address documents, receipts and invoices, and student-to-student shared attachments.

It exists to make one architectural promise enforceable:

> **A domain context holds a `FileRef`, never bytes and never a raw storage path.**

Every consumer receives an opaque, non-guessable, immutable handle. Bytes are served only as signed,
expiring, read-only URLs. No storage-vendor identity crosses the module contract. This keeps storage
substitutable, keeps tenant isolation checkable in one place, and prevents every other bounded context
from growing its own private file-handling behaviour.

The module is deliberately **`[GENERIC]`** and deliberately **silent**: it asserts **no aggregate**, it
publishes **no domain event** (`FIL-EVT-*` is declared EMPTY, because `BC-29` is a producer in zero BC
Map §9 rows and minting an event would create an edge the BC Map says does not exist), and it **refuses
to decide** questions that belong to other contexts.

### 1.1 What it deliberately does NOT own

This is the most important boundary in the document, and the most likely thing for an implementer to get
wrong. File & Media **does not decide** whether a share is allowed:

| Question | Answered by | Recorded as |
|---|---|---|
| Are these two students permitted to share? | `BC-11` Social Graph | `FIL-XC-019` |
| What does the message mean, and who is in the conversation? | `BC-12` Messaging | `FIL-XC-020` |
| Is this content acceptable / should it be moderated? | `BC-13` Trust & Safety | `FIL-XC-022` |
| Is this actor authorised to read this object? | `BC-18` Authorization | `FIL-FR-014`ff |
| Is original-quality upload included in the plan? | Entitlement, over `E-19` | `IMPL-1247` |

File & Media **consumes** those answers and enforces the result. If you find yourself writing an
eligibility rule, a conversation-membership rule, or a moderation rule inside `platform/services`, you
have crossed a frozen exclusion.

---

## 2. V1 scope

### 2.1 In scope for V1

- Upload with resolved tenant context, declared purpose and declared content class
- Content-type validation **against byte content**, not against the declared label
- Virus/malware scanning **before** readability — unscanned and failed-scan objects are unreadable
- `FileRef` issuance: opaque, non-guessable, non-enumerable, stable and immutable for the object's life
- Access decisions obtained **exclusively** from `BC-18`; none computed locally
- Three permission scopes: `self`, `guardianOf`, `tenantWide`
- Signed, expiring, read-only URL serving; revocation blocks **new** issuance (residual window disclosed)
- Tenant isolation with two declared isolation classes per purpose
- Replace, soft-delete, permanent delete, retention and erasure execution
- Idempotency on a caller-supplied key for every mutating operation
- Image thumbnails / derivatives
- **Media optimization** (added at v0.2 — see §4)
- **Student-to-student text + file/media sharing** (see §3)
- Consumed `job_runtime` port with a V1 in-process adapter (`ADR-0058`)
- Executable enforcement of the `E-22` consumer list (`ADR-0059`)

### 2.2 Explicitly OUT of scope for V1

- ⛔ **Video and audio.** `FIL-FR-004`, `FIL-FR-005` and `FIL-XC-016` forbid acceptance; `FIL-XC-023`
  restates the prohibition so that the adaptive optimization machinery cannot be misread as admitting
  video. **This was requested and refused** — see §4.3.
- No domain events published, no `platform/services:events` provided or consumed
- No second port surface — the entire capability is the one registered port
- No storage-vendor detail in the contract
- No aggregate asserted beyond the BC Map grant

---

## 3. Student-to-student text + file/media sharing

This is a **V1 feature**, and this package is honest about the fact that its history is the most
contested part of the document.

**The feature:** a student may share a file with another named student. File & Media implements this as a
**share grant** — a named recipient `PersonId` may read a named `FileRef`. The grant:

- conveys **read only** — never replace, delete, re-share, or ownership transfer (`IMPL-1232`)
- requires both parties in the **same isolation class**; cross-class shares are refused (`IMPL-1233`)
- is served **only** through a per-request signed, expiring URL — never a stable shareable link (`IMPL-1234`)
- is **revocable** by the granting actor or a `BC-18`-authorised actor (`IMPL-1235`)
- is bound to the **object**, not the message — unreadable while the object is soft-deleted (`IMPL-1236`)
- **does not decide permission** — the calling context must supply the eligibility answer (`IMPL-1231`)

Tasks `IMPL-1230`…`IMPL-1236`.

### 3.1 The `E-22` / `BC-12` history — why this matters to you

At v0.1 this feature was **specified but unservable**. `E-22`'s consumer list did not include `BC-12`
Messaging — the one context that actually carries a message attachment — so the context that needed a
`FileRef` could not lawfully obtain one. This was recorded as the blocking finding **`FIL-GAP-012`** and
implementation blocker **`B-11`**, rather than being papered over.

It was resolved in two distinct halves, by two distinct acts:

1. **Architecture half** — `ACCEPTED` `ADR-0055` admitted **`BC-12` only** to `E-22` (BC Map **v1.8**,
   **L331**). Necessity was re-derived **per context**: `BC-12` **yes** (it owns the `Message` carrying
   the `FileRef`); `BC-11` **no** (it answers eligibility as a boolean); `BC-13` **no** (it reaches this
   module *outbound* over `E-14`). Two contexts that failed the necessity test were **not** admitted.
2. **Implementation half** — `ACCEPTED` `ADR-0059` made the list **executable in code**:
   `e22ConsumerContexts` in `packages/liboora_contracts/lib/src/ports/file_access.dart` **L79** is the
   single transcription of BC Map L331, and it is enforced on **both** the read and grant paths.

Video/audio messaging stays excluded throughout — no type widening was required to serve this feature.

---

## 4. WhatsApp-style media optimization approach

Added at **v0.2** by `ACCEPTED` `ADR-0056`. The product instruction was for WhatsApp-like media handling:
files should be optimized for fast transfer and low storage, **without becoming unreadable**.

### 4.1 The governing principle — readability first, compression second

`FIL-FR-085` is the requirement the whole approach rests on:

> When the compression target and the readability floor **cannot both be satisfied**, the module
> **SHALL preserve readability** and **SHALL refuse the upload with a typed error** rather than emit an
> unreadable derivative.

This is the deliberate inversion of naive compression. A study-hall student photographing a page of
notes or an ID document needs the text to remain legible; a smaller file that cannot be read is a failed
upload, not a successful optimization.

### 4.2 How the approach works

| Concern | Approach | Identifiers |
|---|---|---|
| **Optimized output is a derivative** | Inherits the original's access decision, tenant class and lifecycle state; regenerable; never the sole copy of any byte; deleted when the original is | `FIL-FR-083`, `FIL-FR-055`…`059` |
| **Classification** | An accepted image is classified **document-like** or **photographic** from **measured** properties | `FIL-FR-084`, `IMPL-1241` |
| **Document-aware profile** | Honours a quality floor and minimum dimension so text stays legible | `FIL-FR-085`, `IMPL-1242` |
| **Perceptual profile** | For photographic images, within declared bounds | `IMPL-1243` |
| **Adaptive selection** | Profile chosen **from measured input properties only** — a caller may **not** dictate it | `FIL-FR-087`, `IMPL-1244` |
| **Never inflate** | Never enlarge an input; never emit a derivative larger in bytes than its original | `FIL-FR-086` |
| **Originals preserved** | Original bytes preserved whenever any of four trigger conditions hold | `FIL-FR-088`, `IMPL-1246` |
| **Original-quality as entitlement** | A **consumed** entitlement answer over `E-19` — not a local decision | `FIL-FR-089`, `IMPL-1247` |
| **Documents lossless only** | PDFs and office documents: **lossless** container-level optimization at most; bytes remain byte-exactly recoverable | `FIL-FR-090`/`091`, `IMPL-1248` |
| **Serving variants** | Optimized variants generated from the bounded, declared derivative-size set | `FIL-FR-092`, `IMPL-1253` |
| **Processing lifecycle** | `RECEIVED → VALIDATING → PROCESSING → READY \| FAILED`; servable only in `READY` | `FIL-FR-092`, `FIL-INV-013` |
| **Idempotency + bounded retry** | Same object + profile never produces a second stored derivative or audit fact | `FIL-FR-093`, `IMPL-1250` |
| **Progress without leakage** | Status reported without exposing storage path, worker identity or internals | `FIL-FR-094`, `IMPL-1251` |
| **Stall timeout** | A stalled `PROCESSING` object is driven to a terminal state | `FIL-FR-095`, `IMPL-1252` |

### 4.3 Two things the specification refused to invent

Both are recorded as open gaps rather than filled with plausible-looking numbers:

- **`FIL-GAP-014` — three values are owed and NOT invented.** No authority supplies a compression
  quality floor, a minimum document resolution, or a processing timeout. `FIL-CFG-010`, `FIL-CFG-011` and
  `FIL-CFG-015` are therefore published **with ranges and owners but no defaults**. An implementer must
  obtain these from the Product Owner; they are not free to be chosen in code.
- **`FIL-GAP-016` — V1 video/audio optimization was REQUESTED and REFUSED.** The instruction asked for
  adaptive video compression/transcoding at V1. Three frozen requirements forbid it and **no Rank 1–4
  authority admits video** — `MASTER_PRD.md` contains **zero** occurrences of *"video"* or *"audio"*, and
  the only mention anywhere places *"Videos (V3)"*. Precedence could not promote it, because precedence
  promotes from a **higher**-ranked document and there is nothing above V3. **Remedy:** a Rank 1 or Rank 4
  authority must admit video to V1 first; only then may an ADR lift `FIL-XC-016`. `FIL-FR-087`'s
  adaptivity is deliberately generic so admitting a class later is a **configuration** change, not a
  redesign.

`FIL-FR-095` and `FIL-CFG-015` exist because writing the amendment **exposed a hole in v0.1**: nothing
bounded `PROCESSING`, so a stalled object would have been permanently unservable *and* never terminal.

---

## 5. Current implementation status

### 5.1 What genuinely exists in code

| Item | Evidence |
|---|---|
| `files` port interface with executable `E-22` transcription | `packages/liboora_contracts/lib/src/ports/file_access.dart` **L79** |
| `E-22` consumer guard enforced on read **and** grant paths | `lib/platform/services/services.dart` **L273**, guards at **L289**/**L303** |
| `job_runtime` port + V1 in-process adapter | `ADR-0058`; `InProcessJobRuntime` |
| Architecture test suite | `test/architecture/` — **11 entries / 16 test files** |
| Test suite result | `flutter test` → **+287 passing, 0 failures** |
| Static analysis | `flutter analyze lib/ test/ packages/` → **No issues found** |

### 5.2 What does NOT exist — the honest ledger

- ⛔ **0 of 96 `FIL-AC-*` acceptance criteria are proven against real storage.** The architecture tests
  prove the *architecture* is lawful and enforced. They do not prove the capability works. There is no
  storage adapter, no upload path, no scanner integration, no signed-URL issuance against a real bucket.
- ⛔ **Of 61 `IMPL-1200`…`IMPL-1260` tasks, the overwhelming majority are unimplemented.** Only the Wave 6
  port-and-guard declarations have code behind them.
- ⛔ **Three `FIL-GAP-*` remain OPEN by deliberate refusal** — not by oversight:
  - **`FIL-GAP-008`** — retention/legal authority absent (also: no Stage 1 discovery artefact exists)
  - **`FIL-GAP-013`** — co-membership question belongs to `BC-11`, unanswered there
  - **`FIL-GAP-016`** — V1 video/audio, requested and refused (§4.3)
- ⚠ **`ADR-0058` §7 records that V1 media processing is NOT multi-instance safe.** The in-process adapter
  is a V1 accommodation. Do not deploy multiple instances against shared storage on this basis.
- ⚠ **`GCP-23`** — `tool/module_dependencies.yaml` **L242**'s `domain/social` grant is *module*-grained
  while `E-22` is *context*-grained. Deliberately not widened, because widening would admit two contexts
  that **fail** the necessity test. `ADR-0059` makes it harmless at the code boundary. Disclosed, not erased.

### 5.3 ⚠ Stale clauses inside the frozen PRD — disclosed, deliberately NOT edited

**Five locations** in `PRD-017_FILE_AND_MEDIA.md` — **L8**, **L16**, **L1694**, **L1731** and **L1788** —
assert statements that were true when written and are **now false in fact**, namely that *no `lib/` code
implements `FIL-FR-006`'s consumer check* and that *all seven required architecture tests are missing*.
Both are contradicted by the evidence in §5.1 above.

**These were verified false and deliberately left in place.** Three reasons:

1. `PRD_LIFECYCLE.md` **L177-180**: *"A frozen PRD is never silently modified. Not for an obvious
   correction, and not for one that is certainly right… If a silent edit is acceptable when the editor is
   confident, the freeze protects nothing, because every editor is confident."*
2. `ADR-0059` **L11** declares `Amends: Nothing. No PRD, no BC Map, no matrix, no manifest, no EA`. An ADR
   cannot confer an authority it explicitly disclaims.
3. A lifecycle-conformant correction requires an ADR **before** the edit, by the **Product Owner /
   Architecture Owner**. That act is **routed, not performed here.**

Two further occurrences at **L1882** and **L1883** are **change-history rows** and are *correctly* frozen
in time — a historical record should state what was true at its date.

**Reader guidance:** where those five clauses and §5.1 disagree, **§5.1 is the measured fact**. The
condition is met in code; the frozen document has not yet been authorised to say so.

### 5.4 Verification results for this package

| Check | Result |
|---|---|
| PRD status | **`FROZEN`** ✅ (PRD L8, and conferred by `DOCUMENTATION_BASELINE.md` L194) |
| PRD version | **v0.2** ✅ |
| `prd017_stage5.py` | **EXIT 0 — PASS** ✅ |
| `prd017_traceability.py` | **EXIT 0 — PASS** ✅ |
| Identifier registers | 8 registers, **277** identifiers, all contiguous `001..N`, **0 collisions** in all three directions ✅ |
| `FIL-FR-` / `BR-` / `INV-` | 95 / 19 / 13 — §2M of the traceability matrix agrees ✅ |
| `FIL-XC-` / `AC-` / `CFG-` / `GAP-` | 23 / 96 / 15 / 16 — §2M agrees ✅ |
| `FIL-EVT-` | **EMPTY** — registered empty *and* empty in fact ✅ |
| Acceptance coverage | 150 Class A obligations, **112 carry a criterion = 74.7%** (not rounded) |
| Implementation tasks | **61** definition rows, span `IMPL-1200`–`IMPL-1260`, **0 gaps, 0 duplicates** ✅ |
| Dangling references | **0 broken `.md` links repository-wide** ✅ |
| Secrets / `.env` / keystores | **0** — every match is prose *about* security policy ✅ |
| Package contents | 26 documents + this README; 25 `.md` + 1 `.yaml`; no `.git`, no build output, no implementation code ✅ |
| `flutter analyze` | No issues found ✅ |
| `flutter test` | +287 passing, 0 failures ✅ |

---

## 6. What is included in this package

```
README.md                        ← this file
01-prd/
  PRD-017_FILE_AND_MEDIA.md                        the FROZEN PRD, v0.2 (the centrepiece)
  PRD-017_STAGE4_REQUIREMENTS_REVIEW.md            14 adversarial categories, 6 defects fixed
  PRD-017_STAGE5_CONFERRAL.md                      conferral record, two checkers both exit 0
  PRD-017_STAGE7_FREEZE.md                         the Stage 7 freeze record
02-architecture/
  PRD-017_ARCHITECTURE_ALIGNMENT.md                Stage 3, PASS — CONDITIONAL, 6 of 6
  PRD-017_ARCHITECTURE_ALIGNMENT_SUPPLEMENT.md     re-measured against current bytes, verdict unchanged
  LIBOORA_BOUNDED_CONTEXT_MAP.md                   v1.8 — L331 is the authoritative E-22 row
03-adr/
  ADR-0054  Accepted   PRD-017 v0.1 baseline / freeze
  ADR-0055  Accepted   E-22 consumer list admits BC-12 (architecture half of FIL-GAP-012)
  ADR-0056  Accepted   v0.2 — media optimization admitted to V1
  ADR-0057  Accepted   media processing configurable values (45 supplied, 5 refused)
  ADR-0058  Accepted   job_runtime port for V1 media processing
  ADR-0059  Accepted   E-22 consumer list enforced in code (implementation half)
  ADR-0012  Accepted   scaffold-port debt — precedent
  ADR-0013  Accepted   capability-context ownership — creates BC-29 → PRD-017
  ADR-0016  Accepted   E-22 + BC-10 — the one-cell amendment precedent
  ADR-0020  Accepted   freeze confers status, it does not renumber
  ADR-0022  ⚠ PROPOSED — NOT BINDING (see §6.1)
  ADR-INDEX.md                                     46 accepted · 13 proposed · 59 files
04-implementation/
  PRD-017_IMPLEMENTATION_TASKS.md                  61 tasks, IMPL-1200…1260, six waves
  TRACEABILITY_MATRIX.md                           §2M is PRD-017's register; the gates validate against it
05-governance-context/
  DOCUMENTATION_BASELINE.md                        confers rank and status; BASELINE-2026-08-20-C
  PRD_REGISTRY.md                                  L307 is the PRD-017 registry row
  PRD_LIFECYCLE.md                                 the amendment and freeze rules
  CONFIGURATION_GUIDE.md                           v1.2 — §2C holds the 45 supplied FIL-CFG-* values
  module_dependencies.yaml                         the module/port manifest
```

### 6.1 ⚠ `ADR-0022` is `Proposed` — it binds nothing

`ADR-0022` frames the same `E-22` consumer question for **`BC-03`**. It is included **for context only**
because it is cited by the PRD-017 document set. It has **deliberately never been promoted to
`Accepted`**. Do **not** implement against it. The binding `E-22` authority is **BC Map v1.8 L331** as
amended by `ADR-0055` and enforced by `ADR-0059`.

### 6.2 What is deliberately NOT included

Implementation code (`lib/`, `packages/`, `test/`), build output, caches, `.git`, `.env` files,
keystores, signing keys and `google-services.json`. This is a **documentation** handoff. The code
referenced in §5.1 lives in the repository.

### 6.3 Six outward links

The 7 core PRD-017 documents link outside this package **6 times**. Each is a **precedent citation** to
another PRD's records (`PRD-008` supplement, `PRD-013` supplement, and the `PRD-013`/`016`/`014`/`023`
task documents) — evidence of how a similar question was previously settled, **not** a PRD-017
dependency. Nothing required to understand or implement `PRD-017` is missing.

---

## 7. What comes next

This package closes governance. It does **not** authorise coding the capability. The remaining path, in
this order — **each stage depends on the one before it**:

### Stage A — Technical Specification ← THE IMMEDIATE NEXT STEP

Translate the 150 Class A obligations into technical design: the processing pipeline, the profile
selection algorithm, derivative naming and addressing, the scanner integration contract, the signed-URL
issuance mechanism, idempotency key construction, the state machine, error taxonomy and retry semantics.

**Blockers to clear first:** `FIL-GAP-014`'s three missing configuration values must be obtained from the
Product Owner. They cannot be invented during specification.

### Stage B — Database / Storage design

Object metadata schema; the `tenant_id` column on every tenant-scoped row and its presence in **every**
cache key, lookup key and index; the two isolation classes; the share-grant table; derivative tracking;
retention/erasure execution; the bucket layout and lifecycle policy.

⚠ **Do not invent a tenancy rule here.** `BC-10`/`BC-11`→`BC-17` are **GLOBAL** identity contexts under
rule `ID-2`. A global object gets **no `tenant_id`**, and that is deliberate.

### Stage C — API specification

The single registered port surface — no second surface. Upload, resolve, grant, revoke, replace, delete,
status. Idempotency keys on every mutating operation. Refusals on `self`/`guardianOf` must be
**indistinguishable from not-found**. Progress reporting must leak no storage path or worker identity.

### Stage D — Flutter implementation

UI and client integration: upload with progress, the processing lifecycle surfaced to the user, thumbnail
and variant display, share and revoke flows, and correct handling of the `READY`/`FAILED` terminal states.

### 7.1 Definition of done for this module

The module is **`VERIFIED`** — not merely `FROZEN` — when **96 of 96 `FIL-AC-*`** are proven by tests
against real storage, **61 of 61** `IMPL-1200`…`1260` tasks are implemented, and the three open
`FIL-GAP-*` are closed by authority (or explicitly accepted as permanent V1 limitations). **None of that
is true today.**

---

## 8. Reading order for a developer new to this module

1. **This README** — orientation and the honest status
2. `01-prd/PRD-017_FILE_AND_MEDIA.md` §1–§4 — scope and functional requirements
3. `02-architecture/…_ARCHITECTURE_ALIGNMENT.md` — why the boundaries are where they are
4. `02-architecture/LIBOORA_BOUNDED_CONTEXT_MAP.md` **L331** — the authoritative `E-22` row
5. `03-adr/ADR-0055` then `ADR-0059` — how student-to-student sharing became lawful, then enforced
6. `03-adr/ADR-0056` — the media optimization decision and its refusals
7. `04-implementation/PRD-017_IMPLEMENTATION_TASKS.md` — the 61 tasks in six waves
8. `01-prd/PRD-017_FILE_AND_MEDIA.md` §14 — the 96 acceptance criteria you must eventually satisfy

### 8.1 Three rules that will save you a rewrite

1. **A domain context holds a `FileRef`, never bytes and never a storage path.**
2. **This module refuses to decide eligibility, message semantics and moderation.** Consume those answers.
3. **Readability outranks compression.** When they conflict, refuse the upload — never emit an unreadable
   derivative.

---

*Package assembled 2026-08-21 from the frozen PRD-017 document set. No PRD-017 requirement was modified,
reopened or unfrozen in producing it. Where this README and the authoritative documents disagree, the
authoritative documents govern — except in §5.3, where the disagreement is itself the disclosure.*
