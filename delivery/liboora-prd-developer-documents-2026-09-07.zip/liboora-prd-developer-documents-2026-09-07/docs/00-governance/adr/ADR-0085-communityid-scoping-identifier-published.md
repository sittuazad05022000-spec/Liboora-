# ADR-0085 — `communityId` is published as `BC-15`'s community/group scoping identifier by APPEND to the BC Map; A4 is allocated to the Community & Groups foundation; and the `PRD-020` rank question is PREPARED, not answered

| Field | Value |
|---|---|
| **Status** | **Accepted** — 2026-09-01 |
| **Date** | 2026-09-01 |
| **Deciders** | **Architecture Owner** for §3 (`communityId`, the BC Map append) · **Product Owner** for §2 (A4 scope allocation, A4 role confirmation) and §5 (`D10-10` parent link) — authority conferred directly by the human principal of this engagement in *"PRD-021A OWNER RULINGS — APPLY THESE RECOMMENDATIONS"*, in the identical form `ADR-0083` §1 and `ADR-0084` record. ⛔ **No Governance Owner act is taken** — see §4. ⛔ **No personal name is recorded** (`PRD_OWNERSHIP_MODEL.md` §7 rule 4). ⛔ **No ARB quorum, attendee list or sign-off date is asserted** |
| **Supersedes** | — |
| **Amends** | **`LIBOORA_BOUNDED_CONTEXT_MAP.md`** v1.9 → **v1.10**, by **APPEND ONLY** — a new **§16** below the last line, plus the header `Version` cell and one changelog row. ⛔ **§1–§15 are byte-identical.** No line is inserted into §7, §8 or §15 |
| **Amended by** | — |
| **Baseline** | ⛔ **No baseline re-issue.** The BC Map is **Rank 4**; `DOCUMENTATION_BASELINE.md` §7 rule 4 moves the identifier only on a **Rank 1–3** version change. `DOCUMENTATION_BASELINE.md` is **byte-unchanged** — sha256 `7e1c69f92363a5e5…` before and after |
| **Closes** | ✅ **`LCG-GAP-006`** — no published contract mints or resolves `communityId` (A4 **L643**) · ✅ **`LCG-ADR-003`** — the ADR A4 **L675** records as *"Required, `Proposed`"* · ✅ **`LCG-GAP-001`** — A4's scope allocation (§2) · ✅ **`LCG-DEC-003`** re-confirmed, not re-decided (§2.2) |
| **Does NOT close** | ⛔ **`PRD-020`'s rank** — §4 **prepares the decision request and stops.** No rank is invented, proposed or implied · ⛔ **`LCF-GAP-011`** — `integration_test/` (§6) · ⛔ **`LCG-ADR-002`** — `BC-15` still sources zero edges · ⛔ **`GAP-BC15-ANALYTICS`**, **`GAP-BC14-RANK`**, **`LCG-DEC-005b`** · ⛔ **`TASK-D10`** and the 9 `app -> domain/library` violations (§5) · ⛔ **and it does NOT confer Stage 7, does NOT create a baseline row, and does NOT make `PRD-021A` `READY`, `APPROVED` or `FROZEN`** |
| **Related** | `ADR-0078` §2.1 — *"`BC-15`-owned community identifiers"*, **the existing concept this ADR names rather than invents** · `ADR-0079` §8.5 **Option A** — the append-only method reused · `ADR-0083` §4.5 **AO-8** and BC Map **§15.5** — the `Community`/`Group` aggregates this identifier keys · BC Map **§15.4** rule **`EV-3`** — *"Community scope is carried by the community's own identifier"* · `ADR-0012` **L181** — `app -> domain/library` *"Not waived"* · `TASK-D10` §7 · `PRD_LIFECYCLE.md` **L159**, **L161**, **L294** |

> ✅ **ACCEPTED 2026-09-01.**
>
> ⭐ **This ADR mints no new concept.** `Accepted` `ADR-0078` §2.1 already rules that `BC-15`'s
> aggregates *"key exclusively on `PersonId` and on **`BC-15`-owned community identifiers**"*, and
> BC Map **§15.4** rule **`EV-3`** already states that *"Community scope is carried by **the
> community's own identifier**, which is not tenant-derived."* Both are `Accepted`. **What was
> missing was a name and a published contract, not a decision.** §3 supplies exactly those and
> nothing more.
>
> ⭐⭐ **One of the four rulings is deliberately NOT executed.** Ruling 4 instructs *"Do not invent
> a rank… stop for the Governance Owner's explicit rank ruling."* §4 is therefore a **prepared
> decision request**, not a decision. An ADR that executed three rulings and quietly
> half-executed the fourth would be the more comfortable document and the less honest one.

---

## 1. Context

At commit `1159ed8`, `PRD-021A` A1–A8 stood at **Stage 6 complete, Stage 7 not conferred**, with four
blockers measured and each routed to a named owner:

| # | Blocker | Owner | State at `1159ed8` |
|---|---|---|---|
| 1 | A4 scope unallocated (`LCG-GAP-001`, A4 **L638** *"blocks everything"*) | Product Owner | ⛔ OPEN |
| 2 | `communityId` unminted (`LCG-GAP-006`, A4 **L643** *"blocks group creation"*) | Architecture Owner | ⛔ OPEN |
| 3 | `PRD-020` has no baseline rank | Governance Owner | ⛔ OPEN |
| 4 | `integration_test/` absent (`LCF-GAP-011`) | Engineering Owner | ⛔ OPEN |

The human principal then supplied rulings for 1, 2 and 5 (`D10-10`), **explicitly withheld** a ruling on
3, and classified 4 as an Engineering dependency not to be faked. This ADR executes what has authority
and records what does not.

---

## 2. Product Owner — A4 scope and roles

### 2.1 A4 scope — ALLOCATED

**Ruling as given:** *"Keep A4 inside `PRD-021A`. Allocate A4 to the Community & Groups foundation. Do
not exclude it."*

✅ **Executed.** Part **A4 — Community Groups & Roles** is allocated to the **Community & Groups
foundation** and **remains a part of `PRD-021A`**, not a standalone PRD.

This is consistent with three existing records and contradicts none:

| Record | Content |
|---|---|
| `PRD_REGISTRY.md` §11.1 | `PRD-021A` owns **`BC-15` Community & Groups**, decomposition **A1**…**A8** |
| `ADR-0083` **PO-3** | *"the measured `BC-15` residue is **Part A4 — Community Groups & Roles**, a part of `PRD-021A`, **not** a standalone PRD"* — `LCG-DEC-001` **CLOSED** |
| `PRD_OWNERSHIP_MODEL.md` §11.1 | `PRD-021A`'s four roles assigned on registration, context `BC-15` |

⭐ **`LCG-GAP-001` is CLOSED.** Its predicate was *"No document allocates scope to Part A4."* That
predicate is now **false**: this ADR allocates it, on Product Owner authority, and this ADR is a
document. The gap closes because the thing it recorded as absent is present — the `ADR-0081` §3 test.

⚠ **What this allocation does NOT do.** It allocates **scope**, not **content**. A4's 15 remaining open
gaps are unaffected; `LCG-GAP-006` is closed by §3 below, on separate authority; `LCG-DEC-005b`
(`Group.name` uniqueness) stays **OPEN, Product Owner**. Allocating a part does not answer a question
asked inside it.

### 2.2 A4 roles — CONFIRMED, not re-decided

**Ruling as given:** *"Confirm the closed role hierarchy `OWNER > MODERATOR > MEMBER`."*

✅ **Confirmed.** ⭐ **This ruling was already executed and is recorded as such.** `ADR-0083` **PO-4**
closed `LCG-DEC-003` with exactly this set and ranking, and BC Map **§15.5** carries it normatively:

> `CommunityRole` ∈ {`OWNER`, `MODERATOR`, `MEMBER`}, closed, ranked `OWNER > MODERATOR > MEMBER`

⛔ **No second decision is taken and no text is re-written.** Re-deciding a closed decision would
produce two authorities for one rule. The ruling is recorded as a **confirmation**.

⚠ **Disclosed, NOT repaired — two stale cells.** `PRD_REGISTRY.md` **L744** still reads *"⛔ **No role
set is defined**"*, and A4 **L639** still routes `LCG-GAP-002` to a *"**VACANT**"* Governance Owner
although `ADR-0083` §6 **registered** the `LCG-` prefix. Both cells are **stale relative to
`ADR-0083`**. Repairing the registry is a **Governance Owner** act; it is routed with the §4 request
and **not performed here**.

---

## 3. Architecture Owner — `communityId` PUBLISHED

**Ruling as given:** *"approve a stable `communityId` as the required community/group scoping
identifier and publish it through the appropriate existing architecture contract. Do not create
duplicate identifiers."*

### 3.1 ⭐ The concept already exists — this names and publishes it

The ruling's *"do not create duplicate identifiers"* constraint is satisfied **by measurement, not by
assertion**:

| Existing record | Text | Status |
|---|---|---|
| `ADR-0078` §2.1 | *"`BC-15`'s aggregates key exclusively on `PersonId` and on **`BC-15`-owned community identifiers**"* | `Accepted` 2026-08-25 |
| BC Map **§15.4** `EV-3` | *"Community scope is carried by **the community's own identifier**, which is **not** tenant-derived"* | Normative, v1.9 |
| A4 **L228** | `communityId` \| Identifier \| *"Mandatory, immutable. Scoping key"* | Specified, unpublished |
| A2 §20.2 | models community scope as `communityId` | Specified, unpublished |

⭐ **Two `Accepted` authorities already presuppose this identifier; neither names it.** A4 **L276**
states the defect precisely: *"no contract defines how a `communityId` is minted or resolved."* The
gap was a **publication** gap.

⭐ **Duplicate check, measured.** `grep -c communityId` on the BC Map at v1.9 → **0**. `grep` across
`docs/10-architecture/` for a competing community-scope key (`communityKey`, `groupId` as a scope,
`communityRef`) → **0**. There is nothing to duplicate. `communityId` is the token A2 and A4 already
use, so publishing any *other* spelling would itself have created the duplicate the ruling forbids.

### 3.2 What is decided

The BC Map gains a new **§16** containing rules **`CID-1`**…**`CID-6`**, which:

1. Name `communityId` as the **required** scoping identifier for `BC-15` `Community` and `Group`.
2. Assign minting authority to **`BC-15`**, the owner of both aggregates (BC Map **§15.5**).
3. Require it to be **stable and immutable** for the lifetime of the aggregate — the ruling's word
   *"stable"*, and A4 **L228**'s *"immutable"*.
4. Forbid derivation from `tenantId` — preserving `ID-2` and `ADR-0078` §2.1 unchanged.
5. Forbid a second scoping identifier — the ruling's *"do not create duplicate identifiers"*.
6. Record that `Group` is scoped **by** a `communityId`, which is what A4 **L393**'s blocked
   creation path needs to proceed.

⛔ **No format, encoding, length or generation algorithm is specified.** The ruling says *"stable"*,
not *"a UUIDv7"*. Choosing a representation is a further decision nobody made, and inventing one here
would be exactly the fabrication this engagement forbids. `CID-6` records that residue explicitly.

### 3.3 ⭐ Why APPEND — stated as measurement, not preference

Measured independently at this commit, over all of `docs/` and `tool/`, resolving every `Lnnn` token
appearing in the same clause as a BC Map reference:

| | Value |
|---|---|
| BC Map line-citations (tight-window) | **2,753** |
| Distinct plausible cited lines ≤ 763 | measured |
| **Highest genuine cited line** | ⭐ **L673** |
| BC Map length at v1.9 | **763** lines |
| ⭐ **Citations invalidated by an append below L763** | ⭐ **0** |

Three higher candidates were **opened and read, and all three are false positives** — they cite other
documents on a line that also happens to mention the BC Map:

| Candidate | Citing line | Verdict |
|---|---|---|
| `L753`, `L757`, `L762` | `PRD-004_SECOND_INDEPENDENT_REVIEW.md:415`/`:830` | ⛔ **False positive** — `§7.4 L762` cites `PRD-004`'s own §7.4; the BC Map reference in the same cell is `§8 L408` |
| `L724` | `PRD-023_STAGE1_DISCOVERY.md:312` | ⛔ **False positive** — `L722, L724` cite `Library_PRD_v1.md`; the BC Map reference is `§8 BC-06` with no line |
| `L761` | `ADR-INDEX.md:109` | ⛔ **False positive** — the figures are citation *counts* (`2,812`), not line numbers |

⭐ **This reproduces, by independent measurement, the method `ADR-0079` §8.5 Option A established for
the EA and `ADR-0083` applied to this same file.** An insertion into §7 was measured by `ADR-0083` to
cost **1,293** citations and into §8 **747**. An append costs **0**. `ADR-0075`'s §8.5 **Option B** is
**NOT executed and NOT required** — `ADR-0083` already demonstrated that a `BC-15` register extension
is achievable at zero citation cost by append.

⚠ **One deliberate insertion, disclosed:** the changelog row for v1.10. The BC Map changelog is
newest-first, so the row must go at the top of §Changelog. `ADR-0083` accepted the identical cost for
the identical reason — *"a changelog that omits its own current version is the worse defect."* Its
blast radius is measured in §7.

---

## 4. ⛔ Governance Owner — `PRD-020`'s rank is PREPARED, NOT ANSWERED

**Ruling as given:** *"Do not invent a rank. Prepare the exact Governance decision request and stop
for the Governance Owner's explicit rank ruling."*

⛔ **STOPPED.** No rank is assigned, proposed, implied or defaulted in this ADR or in any document it
touches. The request follows.

### 4.1 The decision requested

> **Assign `PRD-020 — Trust & Safety` a precedence rank in `DOCUMENTATION_BASELINE.md` §3, or record
> a reasoned refusal.**

### 4.2 Why it is required

| Link | Evidence, read at its line |
|---|---|
| The gate | `PRD_LIFECYCLE.md` **L159** — Stage 7's gate is *"a row in `DOCUMENTATION_BASELINE.md` §3 at an assigned precedence rank"* |
| The rule | `PRD_REGISTRY.md` **L624** — *"`FROZEN` is set **only** when the document appears in `DOCUMENTATION_BASELINE.md` §3 at Rank 1–5"* |
| The dependency | `PRODUCT_IMPLEMENTATION_ROADMAP.md` **L161–164** gates `PRD-021`/`PRD-021A` behind `PRD-020` |
| The routing | `ADR-0082` **L450** item 5 — *"Release `PRD-020` to a rank \| Governance Owner + `PRD-020` owner"* |

### 4.3 The measured state of `PRD-020`

| Measurement | Result |
|---|---|
| `PRD_REGISTRY.md` **L320** status | **`PLANNED`** |
| Occurrences in `DOCUMENTATION_BASELINE.md` §3 (L121–232) | ⛔ **0** |
| Stage records on disk | Stage 3, Stage 4 (×2), **Stage 5 CONFERRED**, traceability reconciliation, implementation tasks |
| ⚠ Its own header claim | *"Stage 2 — Stages 3–9 not started"* — **measured FALSE**, recorded as `LCF-GAP-015` by `ADR-0082` |
| Rank-conferring effect of Stage 5 | ⛔ **None.** Stage 5 confers `APPROVED`, **not** rank |

### 4.4 What the Governance Owner must decide, and what nobody else may

| Question | Answerable by measurement? |
|---|---|
| Does `PRD-020` appear in baseline §3? | ✅ Yes — **no** |
| Has it reached Stage 5? | ✅ Yes — **yes**, CONFERRED |
| **What rank should it hold?** | ⛔ **NO.** A rank is a **precedence judgement**, not a fact about the filesystem |
| May this ADR supply one? | ⛔ **NO.** §3 is **Rank 1**; `DOCUMENTATION_BASELINE.md` §7 rule 1 requires *an ADR before the change*, and the amending authority is the **Governance Owner**, constituted **VACANT** at `ADR-0080` **L85** |

### 4.5 Two consequential requests, routed with it

1. **`PRD_REGISTRY.md` L744** — repair the stale *"No role set is defined"* cell (superseded by
   `ADR-0083` **PO-4**).
2. **A4 L639** — `LCG-GAP-002` still cites a *"VACANT"* Governance Owner although `ADR-0083` §6
   **registered** the `LCG-` prefix.

⛔ Neither is performed here. Both are registry/governance surfaces.

---

## 5. Product Owner — `D10-10` parent→student link

**Ruling as given:** *"use an explicit parent→student relationship/link model; do not infer the
relationship from unrelated data."*

✅ **Recorded as the Product decision `TASK-D10` §3.3 requires.** `TASK-D10` tables three options; the
ruling selects **Option B** — *"Look up a real link via `studentAccountLinks`"* — an **explicit link
model** — and **excludes** the inference route.

⭐ **What this ruling forbids is the more important half.** `kDemoChildPhone` (`session.dart:26`) is
precisely *"inferring the relationship from unrelated data"* — a hardcoded phone constant standing in
for a relationship. The ruling makes its deletion mandatory rather than optional.

⛔ **`TASK-D10` is NOT executed by this ADR, and the 9 module-boundary violations are NOT closed.**

| Reason | Evidence |
|---|---|
| The task has an unmet **external** prerequisite | `TASK-D10` **§7** — it *"cannot complete before a real OTP delivery path exists"*, an SMS provider under **`MP-DEP-03`**, recorded in `MASTER_PRD.md` **L570** as a **V1 external launch dependency** |
| The violations must stay red | `ADR-0012` **L181** — *"`app -> domain/library` \| **Not waived.** Closes with `TASK-D10`"*; **L160** — the red gate *"is the correct signal: `TASK-D10` is not done"* |
| Ruling 6 | *"Treat the required SMS/OTP provider as an Engineering dependency. Do not fake, waive, or silence `TASK-D10`."* |

⛔ **No waiver is written. No `banned_imports` entry is relaxed. No checker is edited.** The Product
decision is recorded so that `TASK-D10` can proceed **when its Engineering dependency lands**.

---

## 6. ⛔ Engineering — `integration_test/` is NOT created

**Ruling 6 as given:** *"Do not fake… Never invent… infrastructure… merely to make a gate pass."*

⛔ **Not created**, and the reason is substantive rather than jurisdictional:

| Measurement | Result |
|---|---|
| `integration_test/` on disk | **ABSENT** |
| `integration_test` in `pubspec.yaml` | **absent** |
| `lib/domain/social/` contents | **2 files**, both messaging — `social.dart`, `enforcement_projection.dart` |
| Community / feed / group implementation in `lib/` | ⛔ **0 files** |
| The two criteria it must carry | `LCF-AC-035` cross-tenant isolation of **community posts**; `LCF-AC-036` pagination stability of the **feed** |

⭐ **The directory could be created in one command. Neither acceptance criterion could then be
written**, because the subject under test does not exist — `PRD-021A` is at **Stage 6** (tasks
allocated), not Stage 8 (code written). A2 **L1675** already states the correct disposition:
*"closing it would claim a test that has nowhere to live."*

**`LCF-GAP-011` stays OPEN.** It unblocks during Stage 8 implementation, not before.

---

## 7. Blast radius, measured after execution

| Measurement | Result |
|---|---|
| BC Map lines | ⚠ **763 → 847** (+84: §16 = **83** lines, changelog row = 1). ⭐ **CORRECTED TO THE MEASUREMENT** — see §7.1 |
| Highest genuine BC Map citation | ⚠ **L649**, not L673 — **CORRECTED**, see §7.2 |
| ⭐ Citations invalidated by §16 (the append) | ⭐ **0** — confirmed after execution |
| ⚠ Citations invalidated by the changelog row | ⚠ **1** — `PRD-021A_STAGE4_AC_REQUIREMENT_MAPPING_2026-09-01.md` **L524**; see §7.3 |
| **FROZEN** documents modified | ⛔ **0** |
| **Rank 1–3** documents modified | ⛔ **0** |
| `DOCUMENTATION_BASELINE.md` | **byte-unchanged**, sha256 `7e1c69f92363a5e5…` |
| `PRD_LIFECYCLE.md` | **byte-unchanged**, sha256 `5031fcc97a95980e…` |
| Historical/dated records edited | ⛔ **0** |
| `Accepted` ADR decision text edited | ⛔ **0** |
| Identifiers minted | **`CID-1`…`CID-6`** — a new rule block in a new section, collision-checked (§8) |
| Bounded contexts / edges / events / permissions minted | ⛔ **0** |

### 7.1 ⚠ The predicted line count was wrong, and is corrected rather than overwritten

This section, before execution, predicted **763 → 806 (+43: §16 = 42 lines)**. The executed §16
measured **83 lines**, so the file is **847**, not 806. The prediction understated the addition by
**41 lines** — very nearly double.

**Why:** the estimate was made from the *rule count* (six `CID-` rules) and assumed a block the size of
§15.3's `PG-1`…`PG-4`. The written section also carries the §16.2 provenance table, the §16.4
measurement table and the §16.5 negative list — three structures the estimate never counted.

**The figure is corrected to the measurement, and the discrepancy is recorded rather than quietly
overwritten**, following `ADR-0079` **§3.3**, which did exactly this when it predicted 21 new EA lines
and measured 54. ⭐ **Nothing about the decision changes.** The line count was never load-bearing: what
matters is that the addition is **below the last line**, and 83 lines below the last line invalidate
exactly as many citations as 42 would — **zero**.

### 7.2 ⚠ The "highest genuine citation" figure is corrected from L673 to L649

The pre-execution sweep reported **L673** as the highest genuine citation. Re-measured with a tighter
instrument that cuts each window at the next document name and then **opens every candidate**, all four
`L673` hits resolve to *"Master PRD **L673**"* — a different document. They are **false positives**.

The highest **genuine** citation into this file is **L649**, in
`PRD-021A_STAGE4_AC_REQUIREMENT_MAPPING_2026-09-01.md` **L524**, pointing at the 28-edge statement.
⭐ **This strengthens the append argument rather than weakening it**: the true ceiling is *lower* than
believed, so the append zone below L763 is wider than claimed.

### 7.3 ⚠ The changelog row's one cost, disclosed and NOT repaired

Fourteen candidate citations resolve at or above **L613**. Opened individually: **11 are false
positives** (four cite Master PRD L673, two cite Dependency Matrix L652, two cite `PRD-004`'s own
§7.4 L753/L757, three record the *v1.8* state and remain true of it), and **one** — `ADR-0083`
**L115** — is version-qualified *"at **L615** in v1.9"*, so it stays true of v1.9 by construction.

⛔ **Exactly one genuine pointer breaks:** `PRD-021A_STAGE4_AC_REQUIREMENT_MAPPING_2026-09-01.md`
**L524** cites **L649**, and the content moved to **L650**. Verified after execution.

**It is deliberately NOT repaired.** That file is a **dated Stage-4 review record**, committed at
`12b0071`, and this engagement's standing prohibitions forbid editing historical Stage-4 review
records. The drift is therefore logged as **`GAP-BCMAP-L649-CITE`** (Architecture Owner, P3 —
navigational, off by one, changes no determination) and left visible.

⭐ **The row could not be avoided.** `DOCUMENTATION_BASELINE.md` **§7 rule 2** requires that *"the
changed document's version is incremented and its changelog updated in the same commit"*. Two evasions
were considered and **rejected**: deleting a blank line elsewhere to hold the count stable would edit
§15, which this ADR declares byte-identical; and omitting the row would break a Rank 1–5 governance
rule to preserve a single off-by-one pointer. `ADR-0083` accepted the identical trade at the identical
cost of one citation.

---

## 8. Collision check for `CID-`

`grep -rn "CID-[0-9]"` across `docs/` and `tool/` before this ADR → **0 occurrences**. The prefix does
not collide with `ID-1`…`ID-6` (identity linkage), `PG-1`…`PG-4` (pagination), `EV-1`…`EV-4`
(envelope), `AR-1`…`AR-7` (architecture rulings) or `E-01`…`E-29` (edges). Rule identifiers inside a
BC Map section follow the established two-letter-plus-ordinal shape of `PG-`/`EV-`, so this reuses the
existing convention rather than introducing one.

---

## 9. Compliance

### 9.1 `DOCUMENTATION_BASELINE.md` §7

| Rule | Discharged |
|---|---|
| 1 — ADR **before** the change | ✅ This ADR |
| 2 — version incremented + changelog in the same commit | ✅ v1.9 → **v1.10**, changelog row, same commit |
| 3 — baseline declaration updated in the same commit | ✅ **N/A by its own terms** — the BC Map is **Rank 4** and §3.2 records no BC Map version cell requiring movement |
| 4 — baseline identifier changes only on Rank 1–3 | ✅ BC Map is **Rank 4**; identifier **unchanged** |

### 9.2 BC Map **L292**

> *"If an edge is not in this table, it does not exist and adding it requires an ADR."*

✅ **Not engaged — no edge is added.** §16 publishes an *identifier rule*, not an edge. `BC-15` still
sources **zero** edges and `LCG-ADR-002` **stays OPEN**.

### 9.3 `PRD_LIFECYCLE.md`

| Line | Rule | Observed |
|---|---|---|
| **L159** | Stage 7's gate is a baseline §3 row at an assigned rank | ✅ **Not claimed.** `PRD-021A` has **0** rows in §3 |
| **L161** | *"Freeze is **conferred, not claimed**"* | ✅ Nothing is claimed |
| **L177** | *"A frozen PRD is never silently modified"* | ✅ **0** frozen documents touched |
| **L294** | *"No fast path. Stage 7 is not skippable"* | ✅ No stage is advanced by this ADR |

---

## 10. What this ADR does **NOT** do

1. ⛔ Does **not** assign, propose, imply or default a rank for `PRD-020`. §4 **stops**.
2. ⛔ Does **not** create a `DOCUMENTATION_BASELINE.md` §3 row for anything.
3. ⛔ Does **not** confer Stage 7, and does **not** make `PRD-021A` `READY`, `APPROVED` or `FROZEN`.
4. ⛔ Does **not** enter Stage 8.
5. ⛔ Does **not** execute `ADR-0075` §8.5 **Option B**, which remains open and unowned.
6. ⛔ Does **not** create `integration_test/`, and does **not** close `LCF-GAP-011`.
7. ⛔ Does **not** execute `TASK-D10`, waive it, or silence the 9 `app -> domain/library` violations.
8. ⛔ Does **not** specify a format, encoding, length or generation algorithm for `communityId`.
9. ⛔ Does **not** create a bounded context, edge, event, aggregate, permission, role or configurable.
10. ⛔ Does **not** modify any **FROZEN** document, any **Rank 1–3** document, or any `Accepted` ADR's
    decision text.
11. ⛔ Does **not** repair `PRD_REGISTRY.md` **L744** or A4 **L639** — both routed in §4.5.
12. ⛔ Does **not** close `LCG-ADR-002`, `LCG-DEC-005b`, `GAP-BC15-ANALYTICS` or `GAP-BC14-RANK`.

---

## 11. Alternatives rejected

| Alternative | Why rejected |
|---|---|
| Insert `communityId` into BC Map **§8** or **§15.5** | Measured: an insertion at §8 costs **747** citations (`ADR-0083` §4.5); §15.5 sits above the last line, so any insertion there shifts §15.6/§15.7. The append costs **0** |
| Execute `ADR-0075` §8.5 **Option B** first | Unnecessary and unowned. `ADR-0083` proved a `BC-15` register extension is achievable at **zero** citation cost by append; Option B is a Governance+Architecture act and the Governance Owner is **VACANT** |
| Assign `PRD-020` a rank *"provisionally"* | ⛔ The ruling forbids it in terms. A provisional rank is a rank |
| Record `PRD-020`'s rank as `NOT APPLICABLE` | ⛔ Refused for the reason `ADR-0082` §2.3 gives: the gate **reaches** `PRD-020`, so it is **UNMET, not INAPPLICABLE** |
| Create an empty `integration_test/` to green the gap | ⛔ Manufacturing a PASS. Neither AC could be written; §6 |
| Waive the 9 `app -> domain/library` sites | ⛔ `ADR-0012` **L181** — *"Not waived"*. Ruling 6 forbids it |
| Specify a UUID format for `communityId` | ⛔ Invention. The ruling says *"stable"*, not a representation |
| Re-decide the A4 role set | ⛔ Already closed by `ADR-0083` **PO-4**. Re-deciding creates two authorities for one rule |
| Repair `PRD_REGISTRY.md` L744 while here | ⛔ Governance surface. Disclosed and routed, not absorbed |

---

## 12. Verdict

✅ **Three rulings executed on valid authority** — A4 scope allocated (`LCG-GAP-001` CLOSED), A4 roles
confirmed, `communityId` published (`LCG-GAP-006` and `LCG-ADR-003` CLOSED) — **at a measured cost of
0 invalidated citations, 0 frozen documents, 0 Rank 1–3 documents and 0 invented values.**

⛔ **One ruling deliberately not executed** — `PRD-020`'s rank is **prepared and stopped**, per its own
terms.

⛔ **Two blockers remain, both with external prerequisites** — `integration_test/` needs a subject to
test, and `TASK-D10` needs an SMS provider under `MP-DEP-03`.

⛔ **`PRD-021A` remains NOT READY and NOT FROZEN. Stage 7 is NOT conferred. Stage 8 is NOT entered.**

---

## 13. ⭐ A4 scope re-confirmed on a second Product Owner conferral (2026-09-01)

A later Product Owner conferral — *"Confirm that Part A4 remains inside `PRD-021A`. Allocate A4 scope
as the Community & Groups foundation. Do not exclude A4."* — was measured against this ADR before any
act was taken.

⭐⭐ **The ruling was ALREADY EXECUTED, by §2.1 of this ADR, in the same words and on the same
authority.** This section records the **confirmation** and the repairs it obliges. It takes **no
second decision**.

### 13.1 Why no new decision was taken

| Test | Measurement |
|---|---|
| Is A4 allocated to the Community & Groups foundation? | ✅ **Yes** — §2.1: *"Part **A4 — Community Groups & Roles** is allocated to the **Community & Groups foundation** and **remains a part of `PRD-021A`**, not a standalone PRD"* |
| Is A4 excluded? | ✅ **No** — §2.1 states it remains a part; `ADR-0083` **PO-3** closed `LCG-DEC-001` to the same effect |
| Is the deciding authority the same? | ✅ **Yes** — this ADR's **Deciders** row records *"**Product Owner** for §2 (A4 scope allocation …)"*, conferred directly by the human principal |
| Is `LCG-GAP-001` closed? | ✅ **Yes** — named in this ADR's **Closes** field; §2.1 records the predicate *"No document allocates scope to Part A4"* as **false** |

⛔ **Re-deciding it would produce two authorities for one rule** — the defect §2.2 of this ADR
already refused for the role hierarchy. `ADR-0033` §7.1 (*"a conferral for one act is not a standing
licence"*) means the second conferral is **spent on confirming**, and confers no licence to re-open a
closed decision or to widen A4's scope.

### 13.2 ⚠ What the re-measurement DID find — a false statement in a later ADR, now repaired

⭐ **`ADR-0086` §8 (written by this author on 2026-09-01) listed `LCG-GAP-001` and `LCG-GAP-006` as
*"all OPEN"* and cited *"`ADR-0081` §3"* for them.** Measured: both are **CLOSED** by this ADR, and a
`grep` of `ADR-0081` for either identifier returns **0** — the citation named the wrong document.
`ADR-0086` is corrected in the same commit as this section, and its §10 records the correction.

⚠ **This is the derived-statement class again** (`GCP-01`/`07`/`11`/`15`): a summary of another
document's state, written from memory of the blocker list rather than re-read from the **Closes**
field of the ADR that closed them. It is recorded, not smoothed over, because the effect was to
**overstate the Stage 7 blocker count** — the direction of error a freeze record must never take.

### 13.3 ⛔ Stale A4 references NOT repaired, and why

| Location | Stale text | Disposition |
|---|---|---|
| A4 draft **L11–17** (provenance block) | *"THE SCOPE ALLOCATION OF THIS PART IS ITSELF OPEN … a CANDIDATE scope, not an allocated one"* | ⛔ **NOT repaired** |
| A4 draft **L638** (gap register) | `LCG-GAP-001` … *"⛔ **OPEN — blocks everything**"* | ⛔ **NOT repaired** |
| A4 draft **L40**, **L758** | *"an **OPEN Product Owner decision**"*, *"`LCG-DEC-001` is open"* | ⛔ **NOT repaired** |

**Reason, measured:** the A4 draft's hash `95af7e30a58cbc37…` (**766** lines, **45,397** B) is
**anchored by SIX records** — `PRD-021A_STAGE4_AC_REQUIREMENT_MAPPING_2026-09-01.md` (**L76**, **L89**),
`PRD-021A_STAGE4_CONFERRAL_2026-09-01.md` (**L308**), `PRD-021A_STAGE6_IMPLEMENTATION_TASKS.md`
(**L8**, which states the hash is *"unchanged by this stage"*), `PRD-021A_STAGE7_READINESS_AUDIT_2026-09-01.md`
(**L332**), `TRACEABILITY_MATRIX.md` (**L2189**, with the byte count) and
`PRD-021A_IMPLEMENTATION_TASKS.md` (**L9**, *"Subjects (byte-unchanged by this document)"*).

⭐ **A one-character edit to the A4 draft would falsify all six simultaneously**, including a line
count and a byte count. This is the **`D-3` test applied a second time and reaching the same answer**:
the conferral authorises *"update only the necessary A4 references"*, and an edit that invalidates six
records is not *necessary* — the allocation is already effective through `ADR-0085`, which outranks a
draft's own provenance note (`DOCUMENTATION_BASELINE.md` §4: Accepted ADRs are **Rank 2**, a
`DRAFT` part is unranked). `PRD_LIFECYCLE.md` **L177** governs: a record is *"never silently
modified … not for one that is certainly right."*

⚠ **Registry L744 likewise NOT repaired** — §2.2 of this ADR already routed it to the **Governance
Owner**, and this conferral is **Product Owner**. Carried unchanged.

### 13.4 ⛔ What this section does not do

Creates **no** requirement, identifier, architecture, permission or scope. Mints **no** `LCG-*`.
Closes **no** further gap — `LCG-GAP-003`, `LCG-GAP-004`, `LCG-GAP-007`…`LCG-GAP-014` remain **OPEN**,
and **11 of A4's 15** `LCG-GAP-*` are still open. Does **not** advance A4 past `DRAFT`, does **not**
confer Stage 3 on A4, and does **not** make A4's 6 blocked tasks (`IMPL-1532`…`IMPL-1537`)
schedulable on any ground other than the allocation `ADR-0085` §2.1 already made.

⛔ **`PRD-021A` remains NOT READY and NOT FROZEN. Stage 7 is NOT conferred. Stage 8 is NOT entered.**
